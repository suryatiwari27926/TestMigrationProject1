import { LightningElement } from 'lwc';

export default class LoginForm extends LightningElement {}