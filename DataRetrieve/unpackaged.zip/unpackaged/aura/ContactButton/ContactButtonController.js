({
    doInit : function(component, event, helper) {

    },

    handleClick: function(cmp, event, helper) {
        var pageReference = {
            type: 'standard__objectPage',
            attributes: {
                recordId: '0015j000007YEGqAAO',
                objectApiName: 'Account',
                actionName: 'home',
                relationshipAPIName: 'Contact'
            }
        }
    }
})